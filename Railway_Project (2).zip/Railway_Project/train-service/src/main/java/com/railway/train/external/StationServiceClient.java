package com.railway.train.external;

import com.railway.train.model.Station;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Optional;

@FeignClient(name = "station-service")
public interface StationServiceClient {
    @GetMapping("/api/station/code/{code}")
    Station getStationByCode(@PathVariable String stationCode);

    @GetMapping("/api/station/id/{id}")
    Optional<Station> getStationById(@PathVariable Long id);
}
