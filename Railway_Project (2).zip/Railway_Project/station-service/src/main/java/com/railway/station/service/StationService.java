package com.railway.station.service;

import com.railway.station.entity.Station;
import com.railway.station.repository.StationRepository;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StationService {

    @Autowired
    private StationRepository stationRepository;

    public ResponseEntity<Station> addStation(Station station){
        return new ResponseEntity<>(stationRepository.save(station), HttpStatus.OK);
    }

    public ResponseEntity<List<Station>>getAllStations(){
        List<Station> allStations = stationRepository.findAll();
        return new ResponseEntity<>(allStations,HttpStatus.OK);
    }

    public Optional<Station> getStationByCode(String stationCode){
        Optional<Station> byStationCode = stationRepository.findByStationCode(stationCode);
        if(!byStationCode.isPresent()){
            throw new RuntimeException("Not found station by station code");
        }
        return byStationCode;
    }

    public Optional<Station> getStationById(Long id){
        return stationRepository.findById(id);
    }

    public ResponseEntity<String> deleteById(Long id){
        stationRepository.deleteById(id);
        return new ResponseEntity<>("Deleted Successfully",HttpStatus.OK);
    }
}
