package com.railway.station.controller;

import com.netflix.discovery.converters.Auto;
import com.railway.station.entity.Station;
import com.railway.station.service.StationService;
import jakarta.ws.rs.Path;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/station")
public class StationController {

    @Autowired
    private StationService stationService;

    @PostMapping("/add")
    public ResponseEntity<Station> addStation(@RequestBody Station station){
        return stationService.addStation(station);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Station>> getAllStations(){
        return stationService.getAllStations();
    }

    @GetMapping("/code/{code}")
    public Optional<Station> getStationByCode(@PathVariable String code){
        return stationService.getStationByCode(code);
    }

    @GetMapping("/id/{id}")
    public Optional<Station> getStationById(@PathVariable Long id){
        return stationService.getStationById(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteStationById(@PathVariable Long id){
        return stationService.deleteById(id);
    }

}
