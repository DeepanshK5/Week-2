package com.railway.gateway_service.filter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.Set;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)          // Make sure this runs first
public class AuthenticationFilter implements WebFilter {

    // ⭐ Add this inside your class
    private static final Set<String> USER_ALLOWED_PATHS = Set.of(
            "/api/trains/all",
            "/api/trains/search",
            "/api/trains/id",
            "/api/station/all",
            "/api/station/code",
            "/api/station/id",
            "/api/bookings/book",
            "/api/bookings/pnr"
            // Add more paths user is allowed to access
    );


    // --- 1. Same secret and key spec you use in JwtService ------------------
    @Value("${jwt.secret}")
    private String secret;                  // injected from application.yml

    private SecretKey toKey() {
        return new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8),
                "HmacSHA256");
    }

    // Endpoints that do NOT need authentication
    private static final Set<String> PUBLIC_PATHS = Set.of(
            "/api/users/login", "/api/users/register",
            "/v3/api-docs", "/swagger-ui", "/swagger-ui.html"
//            ,"/api/trains/search"
    );

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {

        String path = exchange.getRequest().getPath().value();
        System.out.println(path);

        // 2. Bypass public routes & swagger
        if (PUBLIC_PATHS.stream().anyMatch(path::contains)) {
            return chain.filter(exchange);
        }

        HttpMethod method = exchange.getRequest().getMethod();

        if (HttpMethod.OPTIONS.equals(method)) {
            return chain.filter(exchange);
        }

        if (method != null && HttpMethod.OPTIONS.equals(method)) {
            System.out.println("Inside method != null && HttpMethod.OPTIONS.equals(method)");
            return chain.filter(exchange);
        }


        // 3. Extract and validate the token
//        String authHeader = exchange.getRequest()
//                .getHeaders()
//                .getFirst(HttpHeaders.AUTHORIZATION);

        String authHeader = exchange.getRequest()
                .getHeaders()
                .getFirst("Authorization");

        System.out.println("now auth Header is "+authHeader);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            System.out.println("Missing or invalid Authorization header. I am defined in Authentication Filter");
            return unauthorized(exchange, "Missing or invalid Authorization header");
        }

        String token = authHeader.substring(7);


        System.out.println("JWT token from request: " + token);
        System.out.println("Requested URI: " + exchange.getRequest());

        Claims claims;
        try {
            claims = Jwts.parser()
                    .verifyWith(toKey())               // HS‑256
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (io.jsonwebtoken.ExpiredJwtException ex) {
            return unauthorized(exchange, "Token expired");
        } catch (Exception ex) {
            return unauthorized(exchange, "Token malformed/invalid");
        }

        /* 4.  Propagate useful data keeps the downstream services stateless.   */
        String username = claims.getSubject();                // same as user‑service
        String role     = claims.get("role", String.class);
        String email     = claims.get("email", String.class);


        // --- 4) Role based access control ---
        if ("USER".equalsIgnoreCase(role)) {
            boolean allowed = USER_ALLOWED_PATHS.stream()
                    .anyMatch(path::startsWith);

            if (!allowed) {
                exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
                exchange.getResponse().getHeaders()
                        .add("Error-Message", "Access denied: USER role cannot access this endpoint");
                return exchange.getResponse().setComplete();
            }
        }
// ADMIN → no restriction allowed to access all routes


        ServerWebExchange mutated = exchange.mutate()
                .request(builder -> builder
                        .header("X-Auth-Username", username)
                        .header("X-Auth-Role",     role == null ? "USER" : role)
                        .header("X-User-Email", email)
                ).build();

        return chain.filter(mutated);
    }

    private Mono<Void> unauthorized(ServerWebExchange ex, String msg) {
        ex.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
        ex.getResponse().getHeaders().add("Error-Message", msg);
        return ex.getResponse().setComplete();
    }
}
