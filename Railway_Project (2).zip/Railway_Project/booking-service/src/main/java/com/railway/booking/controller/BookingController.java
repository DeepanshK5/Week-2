package com.railway.booking.controller;

import com.railway.booking.entity.Booking;
import com.railway.booking.service.BookingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping("/book")
    public ResponseEntity<Booking> book(@Valid @RequestBody Booking booking,
                                        @RequestHeader("X-User-Email") String email) {
        return ResponseEntity.ok(bookingService.bookTicket(booking,email));
    }

    @GetMapping("/all")
    public ResponseEntity<List<Booking>> getAllBookings(){
        return new ResponseEntity<>(bookingService.getAll(), HttpStatus.OK);
    }

    @DeleteMapping("/pnr/{pnr}")
    public ResponseEntity<?> cancel(@PathVariable String pnr,
                                    @RequestHeader("X-User-Email") String email) {
        Optional<Booking> booking = bookingService.cancelTicket(pnr,email);
        if (booking.isPresent()) {
            return ResponseEntity.ok("Booking cancelled for PNR: " + pnr);
        } else {
            return ResponseEntity.badRequest().body("PNR not found");
        }
    }
}
